%DEMOFA demo of Factor Analysis
figure;
% generate some training data (from a FA model):

D = 5; % Dimension of the output space
H = 3; % Dimension of the latent space
N = 20; % Number of individuals

F0 = randn(D,H);
h = randn(H,N);  % Rows are latent factors, columns individuals.
X = F0*h + 0.01*randn(D,N); % Rows are output variables, columns individuals.

% Parameters for the FA model:
opts.maxit = 50; opts.plotprogress=1; opts.tol=0.1;

[F,diagPsi,m,loglik]=FA(X,H,opts);
% F: estimated factor loading matrix
% diagPsi: diagonal elements of the noise covariance matrix Psi
% m: mean, sets the origin of the coordinate system

% Plot the true sample covariance
subplot(1,2,1); imagesc(cov(X',1)); title('Sample Covariance');

% Covariance computed using the estimated parameters (see Eq. 21.1.8 in Barber)
subplot(1,2,2); imagesc(F*F'+diag(diagPsi)); title('FA Covariance')