% Use BIC for model selection in GMM

clear all;
rand('state', 999); %#ok<RAND>
randn('state', 999); %#ok<RAND>

%totalComponents=?; %max number of mixture components
load data;
ratio=0.75;
train_Index = randperm(size(X,2),ceil(ratio*size(X,2))); %training data index
test_indices= setdiff(1:size(X,2),train_Index); %test data index
Xtrain=X(:,train_Index); %training data
Xtrain_labels=label(train_Index); %training data labels
Xtest=X(:,test_indices); %test data
Xtest_labels=label(test_indices); %test data labels

%plot training and test data
color = 'brgmcyk';
m = length(color);
c = max(Xtrain_labels);
figure(1);
clf;
hold on;
for i = 1:c
    idc = label==i;
    plot(Xtrain(1,Xtrain_labels==i),Xtrain(2,Xtrain_labels==i),['.' color(i)],'MarkerSize',12);
end
plot(Xtest(1,:),Xtest(2,:),'kd','MarkerSize',5);
title('training data, test data (in black)');

loglik=zeros(totalComponents,1);
BIC = zeros(totalComponents,1);
numParams = zeros(totalComponents,1);

for H=1:totalComponents; % number of mixture components
        opts.plotlik=0;
        opts.plotsolution=0;
        opts.maxit=100;
        opts.minDeterminant=0.0001;
        [P1,m1,S1,loglik1,phgn1] = GMMem(Xtrain,H,opts); % fit to data
      
        loglik(H)=loglik1; %likelihood for this model
        %numParams(H) = ???; % number of parameters in the model
        %BIC(H) = ???; % BIC for the model
end
%plot the BIC curve
figure;
plot(1:totalComponents, BIC,'bo-');
xlabel('Number of Mixture Components');ylabel('BIC')
title('Model Selection (BIC)');
[v,h]=min(BIC); %select the number of mixture components which minimizes the BIC 

%Now train full model with selected number of mixture components
[P1,m1,S1,loglik1,phgn1]=GMMem(Xtrain,h,opts); % fit to data

% Predict using the full trained model
%logl1= ???
%fprintf('Test Data Likelihood=%f\n', ???)

% Plot the best GMM model
figure(3);
clf;
hold on;
for i = 1:c
    idc = label==i;
    plot(Xtrain(1,Xtrain_labels==i),Xtrain(2,Xtrain_labels==i),['.' color(i)],'MarkerSize',12);
end
plot(Xtest(1,:),Xtest(2,:),'kd','MarkerSize',5);
for i=1:H
    [E V]=eig(S(:,:,i));dV=sqrt(diag(V)); 
    theta=0:0.3:2*pi;
    p(1,:)= dV(1)*cos(theta); p(2,:)= dV(2)*sin(theta);
    x = E*p+repmat(m(:,i),1,length(theta));
    plot(x(1,:),x(2,:),'r-','linewidth',2)
end;
title('training data, test data (in black)');

