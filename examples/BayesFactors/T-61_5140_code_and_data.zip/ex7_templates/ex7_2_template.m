% Use CV for model selection in GMM
clear all;
rand('state', 999); %#ok<RAND>
randn('state', 999); %#ok<RAND>

%foldCount = ???;  %number of folds
%totalComponents = ???; %number of mixture components
load data;
ratio=0.75;
train_Index = randperm(size(X,2),ceil(ratio*size(X,2))); %training data index
test_indices= setdiff(1:size(X,2),train_Index); %test data index
Xtrain=X(:,train_Index); %training data
Xtrain_labels=label(train_Index); %training data labels
Xtest=X(:,test_indices); %test data
Xtest_labels=label(test_indices); %test data labels

%plot training and test data
color = 'brgmcyk';
m = length(color);
c = max(Xtrain_labels);
figure(1);
clf;
hold on;
for i = 1:c
    idc = label==i;
    plot(Xtrain(1,Xtrain_labels==i),Xtrain(2,Xtrain_labels==i),['.' color(i)],'MarkerSize',15);
end
plot(Xtest(1,:),Xtest(2,:),'kd','MarkerSize',5);
title('training data, test data(in black)');

loglik=zeros(totalComponents,foldCount); % collect log-likelihoods

Nlearning=size(Xtrain,2);
order = randperm(Nlearning); % you can randomize the order of training samples
                             % when constructing the folds in the loop
for H=1:totalComponents; % number of mixture components 
    for fold=1:foldCount %K-fold cross validation
        
        %training_indices = ???; % cv training sample indices
        
        %val_indices = ???; % cv validation indices

        X_train=Xtrain(:,training_indices);  % cv training data
        Xval=Xtrain(:,val_indices); % cv validation data
        
        %train model
        opts.plotlik=0;
        opts.plotsolution=0;
        opts.maxit=100;
        opts.minDeterminant=0.0001;
        [P1,m1,S1,loglik1,phgn1]=GMMem(X_train,H,opts); % fit model
        
        %Predict using the cv trained model for validation data Xval
        %logl1 = ???; % use GMMloglik
        %loglik(H,fold) = ???
    end
end
% plot the accuracy curve
figure(2);
plot(mean(loglik,2),'bo-');
xlabel('Number of Mixture Components');ylabel('CV Likelihood')
title('Model Selection (Cross Validation)');
[v,h]=max(mean(loglik,2)); %select the number of mixture components which maximizes the loglik 

%Now train full model with selected number of mixture components
[P1,m1,S1,loglik1,phgn1]=GMMem(Xtrain,h,opts); % fit 

% Predict using the full trained model
%logl1= ???
%fprintf('Test Data Likelihood=%f\n', ???)


% Plot the best GMM model
figure(3);
clf;
hold on;
for i = 1:c
    idc = label==i;
    plot(Xtrain(1,Xtrain_labels==i),Xtrain(2,Xtrain_labels==i),['.' color(i)],'MarkerSize',12);
end
plot(Xtest(1,:),Xtest(2,:),'kd','MarkerSize',5);
for i=1:h
    [E V]=eig(S1(:,:,i));dV=sqrt(diag(V)); 
    theta=0:0.1:2*pi;
    p(1,:)= dV(1)*cos(theta); p(2,:)= dV(2)*sin(theta);
    x = E*p+repmat(m1(:,i),1,length(theta));
    plot(x(1,:),x(2,:),'r-','linewidth',2)
end;
title('training data, test data (in black)');
